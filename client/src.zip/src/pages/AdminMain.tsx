import AdminHeader from 'components/admin/AdminHeader';
import AdminMainSection from 'components/admin/AdminMainSection';
import create from 'zustand/react';

// interface adminPageState {

// }
// const useAdminStore = create<adminPageState>((set) => { });
function AdminManageUserSection() {
  return (
    <section className="w-full">
      <div className="h-10 border-b-4 border-b-text-black border-solid text-xl font-semibold text-b-text-black py-1">
        <i className="fa-solid fa-user p-1" />
        <span className="">회원 관리</span>
      </div>
      <div className="flex">
        <div className="w-20">사이드바</div>
        <div>메인영역</div>
      </div>
    </section>
  );
}
export default function AdminMain() {
  return (
    <div className="w-screen max-w-screen-lg">
      <AdminHeader />
      <AdminMainSection />
      {/* <AdminManageUserSection /> */}
    </div>
  );
}
